This dictionary was based on the en_GB Myspell dictionary 
which in turn was initially based on a subset of the 
original English wordlist created by Kevin Atkinson for 
Pspell and  Aspell and thus is covered by his original 
LGPL licence. 

The credit for this en_AU dictionary goes to:

Kelvin Eldridge (maintainer)
Jean Hollis Weber
David Wilson

- Words incorrect in Australian English removed
- a list from the previously removed words with corrected spelling was added
- a list of major rivers was added
- a list of place names was added
- a list of Australian mammals was added 
- a list of Aboriginal/Koori words commonly used was added

A total of 119,267 words are now recognized 
by the dictionary.

Of course, special thanks go to the editors of the 
en_GB dictionary (David Bartlett, Brian Kelk and 
Andrew Brown) which provided the starting point
for this dictionary.

The affix file is currently a duplicate of the en_AU.aff
created completely from scratch by David Bartlett and 
Andrew Brown, based on the published 
rules for MySpell and is also provided under the LGPL.

If you find omissions or bugs or have new words to 
add to the dictionary, please contact the en_AU 
maintainer at:

 "Kelvin" <audictionary@onlineconnections.com.au>



