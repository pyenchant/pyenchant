Dieses W�rterbuch basiert auf dem igerman98 Ispell-W�rterbuch, zu finden
unter http://www.j3e.de/ispell/igerman98/.

Das W�rterbuch und alle enthaltenen Wortlisten sind lizenziert unter der
GNU GPL, Version 2.

Autor: Bjoern Jacke <bjoern@j3e.de>
